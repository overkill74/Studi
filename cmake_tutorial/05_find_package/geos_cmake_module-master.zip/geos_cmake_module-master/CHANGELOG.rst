^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package geos_cmake_module
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.2 (2020-09-04)
------------------
* added license
* Merge branch 'tweak-cmake-extras' into 'master'
  Tweak cmake extras
  See merge request daniel_dsouza/geos_cmake_module!1
* Tweak cmake extras
  This renames the extras.cmake files to be consistent with the package
  name, and it also changes a variable in the installspace file to
  reference the right package.
* works for me
* Contributors: Daniel D'Souza, P. J. Reed
